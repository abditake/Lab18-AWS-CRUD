const dynamoose = require('dynamoose');


// create schema
const peopleSchema = new dynamoose.Schema({
  id: String,
  name: String,
  deckType: String,
});

// creating model

const peopleModel = dynamoose.model('people', peopleSchema);


exports.handler = async (event) => {

  console.log(event.queryStringParameters);

  let {id, name, deckType} = event.queryStringParameters;
  let person = {id, name, deckType};

  let response = { statusCode: null, body: null};

  try {
    let newPerson = await peopleModel.create(person);
    response.statusCode = 200;
    response.body = JSON.stringify(newPerson);
  } catch (e) {
    console.error(e);
    response.statusCode = 500;
    response.body = JSON.stringify(e.message);
  }
};
